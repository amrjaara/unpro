#include<iostream>
#include <string>
#include<stdlib.h>
#include<time.h>
#include <cmath>
#include <bitset>
#include<map>
using namespace std;

struct node
{
  int key;
  node *pre;
  node *next;
    map < int, string > hash;
  int *a = new int[16];
} *tail, *head;
int counter = 0;



struct Hash
{
  const int p = 31, m = 1e9 + 7;
  int hash_value;
    Hash (const string & s)
  {
    int hash_so_far = 0;
    long p_pow = 1;
    const int n = s.length ();
    for (int i = 0; i < n; ++i)
      {
	hash_so_far = (hash_so_far + (s[i] - 'a' + 1) * p_pow) % m;
	p_pow = (p_pow * p) % m;
      }
    hash_value = hash_so_far;
  }
  bool operator== (const Hash & other)
  {
    return (hash_value == other.hash_value);
  }
};





class chord
{


public:


  chord ()
  {
    head = NULL;
    tail = NULL;
  }
  node *create_node (int v)
  {
    counter++;
    struct node *p;
    p = new (struct node);
    p->key = v;
    p->next = NULL;
    p->pre = NULL;
    return p;

  }





  int binaryToDecimal (string n)
  {
    string num = n;
    int dec_value = 0;

    int base = 1;

    int len = num.length ();
    for (int i = len - 1; i >= 0; i--)
      {
	if (num[i] == '1')
	  dec_value += base;
	base = base * 2;
      }


    return dec_value;
  }








  tuple < int, string > hash ()
  {

    string l, ss, s, sa = "";
    string xx = "0000000000000000";
    cout << "please enter your string  ";
    cin >> ss;
    int se;
    Hash h (ss);

    se = h.hash_value;

    s = to_string (se);



    cout << " hashing value is :" << s << endl;
    for (int j = 0; j < s.size (); j++)
      {
	l += bitset < 8 > (s[j]).to_string () + "";

      }
    for (int kk = 0; kk < l.size (); kk += 16)

      {
	sa = "";
	int ys = kk + 16;
	for (int gh = kk; gh < ys; gh++)
	  {
	    sa += l[gh];
	  }
	for (int i = 0; i < 16; i++)
	  {
	    xx[i] = ((xx[i] - '0') ^ (sa[i] - '0')) + '0';
	  }
      }


    int gg = binaryToDecimal (xx);
    cout << " key  is : " << gg << endl;
    return
    {
    gg, s};


  }




  void insert_key (int gg, string k)
  {
    node *t = head;
    for (int li = 1; li <= counter; li++, t = t->next)
      {
	if (gg <= t->key)
	  {
	    cout << " key in node  ( node id)" << t->key;
	    t->hash.insert (pair < int, string > (gg, k));
	    break;
	  }
	if (gg > tail->key)
	  {
	    head->hash.insert (pair < int, string > (gg, k));
	    cout << " key  in node ( node id) " << head->key;
	    break;
	  }

      }

  }











  node *min (struct node *s, int gg)
  {
    int count = 0;


    for (size_t i = 0; i < 16; i++)
      {

	if (s->a[i] <= gg)
	  {
	    count++;

	  }
      }

    if (count == 0)
      return NULL;

    int *aa = new int[count];
    int j = 0;
    for (size_t i = 0; i < 16; i++)
      {

	if (s->a[i] <= gg)
	  {
	    aa[j] = s->a[i];
	    j++;
	  }
      }

    int max = aa[0];
    for (size_t i = 1; i < count; i++)
      {
	if (aa[i] > max)
	  {
	    max = aa[i];
	  }
      }

    node *u = head;
    for (size_t i = 1; i <= counter; i++, u = u->next)
      {

	if (max == u->key)
	  {

	    return u;
	  }
      }


    return NULL;
  }


  void search_value (int key, string hashing, int node)
  {

    struct node *s = head;
    struct node *ss = head;
    struct node *minm = NULL;

    for (int i = 1; i <= counter; i++, s = s->next)
      {

	if (key <= s->key)
	  {
	    s = s;
	    break;
	  }

	else if (key > tail->key)
	  {
	    s = head;
	    break;
	  }

      }


    for (int i = 1; i <= counter; i++, ss = ss->next)
      {
	if (ss->key == node)
	  {
	    ss = ss;

	    break;
	  }
      }

    if (counter != 0 || counter != 1)
      {
	cout << "\n current node is :" << ss->key << endl;
	cout << "destination node is :" << s->key << endl;


	for (; ss != s;)
	  {

	    minm = min (ss, key);
	    if (minm != NULL)
	      {
		ss = minm;

	      }
	    else
	      {
		ss = ss->next;


	      }


	  }
	if (s == ss)
	  {
	    if (hashing == ss->hash.find (key)->second)
	      {



		cout << "node you search on it  is " << ss->key << endl;
		cout << "hashing value is " << ss->hash.find (key)->
		  second << endl;


	      }
	    else
	      {
		cout << "not found";
	      }


	  }

	else
	  {
	    cout << "please enter more node";
	  }
      }




  }

  void update_delete (node * p)
  {



    node *i;
    i = p->next;


  for (auto & x:p->hash)
      {
	i->hash.insert (pair < int, string > (x.first, x.second));
      }

  }

  void print_key ()
  {

    struct node *s = head;


    for (int i = 1; i <= counter; i++, s = s->next)
      {


	cout << "\n " << s->key << " :" << endl;
      for (auto & x:s->hash)
	  {
	    cout << x.first << " - " << x.second << '\n';
	  }

      }
  }






  void update_insert (node * p)
  {
    if (p->next != NULL)
      {
	node *i, *h;
	i = p->next;
	h = p->pre;


	if (p->key < i->key)
	  {
	    for (auto it = i->hash.cbegin (); it != i->hash.cend ();)
	      {
		if (it->first <= p->key)
		  {
		    p->hash.insert (pair < int,
				    string > (it->first, it->second));
		    i->hash.erase (it++);
		    cout << " \t key updated \n";

		  }
		else
		  {
		    ++it;
		  }
	      }
	  }




	else if (h->key < p->key)
	  {

	    for (auto it = h->hash.cbegin ();
		 it != h->hash.cend () /* not hoisted */ ;
		 /* no increment */ )
	      {
		if (it->first > h->key && it->first <= p->key)
		  {
		    p->hash.insert (pair < int,
				    string > (it->first, it->second));
		    i->hash.erase (it++);	// or "it = m.erase(it)" since C++11
		    cout << "\t key updated \n ";
		  }
		else
		  {
		    ++it;
		  }
	      }





	  }
      }

    else
      {
	cout << "one elemant no need update";
      }
  }




  void routing_table ()
  {
    int vv, v, ps, i, t, ds = 0;
    t = 16;
    ps = pow (2, t);
    node *x = head;
    struct node *s = head;
    struct node *ss = tail;

    for (i = 1; i <= counter; i++, x = x->next)
      {

	for (int j = 0; j < t; j++)
	  {

	    v = (x->key + pow (2, j));
	    vv = v % ps;
	    ds = search (vv);

	    if (counter == 1)
	      {


		x->a[j] = x->key;
	      }

	    else if (ds != 0)
	      {


		x->a[j] = ds;
	      }



	    else if (ds == 0 && vv < tail->key)
	      {

		node *ss = head;
		for (int k = 1; k <= counter; k++, ss = ss->next)
		  {


		    if (vv < ss->key)
		      {


			x->a[j] = ss->key;
			break;
		      }
		  }
	      }

	    else if (vv > tail->key)
	      {

		x->a[j] = head->key;

	      }



	  }
	cout << " ";
      }
  }




  void print_routing ()
  {
    node *s = new node;
    s = head;
    cout << " \n routing table \n ";
    for (int k = 1; k <= counter; k++, s = s->next)
      {
	for (int jj = 0; jj < 16; jj++)
	  {
	    cout << "  " << s->a[jj] << " - ";
	  } cout << " \n";
      }
  }





  void insert (int v)
  {
    struct node *p;
    p = create_node (v);

    if (counter < pow (2, 16))
      {


	if (head == tail && head == NULL)
	  {
	    head = tail = p;
	    head->next = tail->next = NULL;
	    head->pre = tail->pre = NULL;
	  }


	else if (p->key < head->key)
	  {
	    p->next = head;
	    head->pre = p;
	    head = p;
	    head->pre = tail;
	    tail->next = head;

	  }

	else if (p->key > tail->key)
	  {
	    tail->next = p;
	    p->pre = tail;
	    tail = p;
	    head->pre = tail;
	    tail->next = head;
	  }


	else
	  {
	    node *s;


	    s = head;

	    for (int i = 1; i <= counter; i++, s = s->next)
	      {
		if (p->key < s->key)
		  {
		    p->next = s;
		    p->pre = s->pre;
		    s->pre->next = p;
		    s->pre = p;



		    break;
		  }
	      }
	  }
	cout << "Element inserted" << endl;

	routing_table ();
	update_insert (p);

      }
    else
      {

	cout << "chord is full we can not add elemant ";
      }

  }



  void delete_pos (int v)
  {
    node *p;


    if (head == tail && head == NULL)
      {
	cout << "List is empty, nothing to delete" << endl;
	return;
      }
    else if (v == head->key)
      {
	p = head;
	tail->next = p->next;
	p->next->pre = tail;
	head = p->next;
	counter--;
	update_delete (p);
	free (p);
      }
    else if (v == tail->key)
      {
	p = tail;
	p->pre->next = p->next;
	p->next->pre = p->pre;
	tail = p->pre;
	counter--;
	update_delete (p);
	free (p);
      }
    if (v != head->key || v != tail->key)
      {

	node *s;
	s = head->next;
	for (int i = 2; i < counter; i++, s = s->next)
	  {
	    if (s->key == v)
	      {
		s->next->pre = s->pre;
		s->pre->next = s->next;
		counter--;
		update_delete (s);
		free (s);


		break;
	      }

	  }
      }



    cout << "Element deleted" << endl;


    routing_table ();


  }


  int search (int v)
  {
    bool flag = false;
    node *s;
    if (head == tail && head == NULL)
      {
	cout << "The List is empty, nothing to search" << endl;
	return 0;
      }
    s = head;
    for (int i = 1; i <= counter; i++, s = s->next)
      {
	if (s->key == v)
	  {
	    flag = true;

	    return s->key;
	  }
      }
    if (!flag)
      {

	return 0;
      }

  }














  void display ()
  {

    node *s;


    if ((head == tail && head == NULL) || counter == 0)
      {
	cout << "The List is empty, nothing to display" << endl;
	return;
      }
    s = head;
    for (int i = 1; i <= counter; i++)
      {
	cout << s->key << " ";
	s = s->next;
      }

  }








};

int
main ()
{
  int i = 0;

  int num, s, px, y, g = 0;
  chord *x = new chord ();

  while (1)
    {

      cout <<
	"\n 1- insert 2- delete 3- search on element 4 -display element 5- display routing table  element 6-hash function 7-search for key 8-print all key 9-exit \n  ";
      cin >> i;
      switch (i)
	{
	case 1:
	  {

	    s = pow (2, 16);

	    srand ((unsigned) time (0));

	    num = rand () % (s - 0) + 0;
	    x->insert (num);
	  }
	  break;


	case 2:
	  {

	    cout << "enter number to delete";
	    cin >> px;
	    x->delete_pos (px);
	  }
	  break;

	case 3:
	  {

	    cout << "  search on element   : \n ";
	    cin >> y;

	    g = x->search (y);
	    if (g != 0)
	      cout << " element found :" << g << "\n";
	    else
	      cout << " element  not found ";
	  }
	  break;



	case 4:
	  {
	    x->display ();
	  }
	  break;



	case 5:
	  {
	    x->print_routing ();
	  }
	  break;
	case 6:
	  {
	    string g = "";
	    int v1;
	    string v2;
	    tie (v1, v2) = x->hash ();
	    x->insert_key (v1, v2);

	  }


	  break;


	case 7:
	  {
	    int i = 0;

	    int v1;
	    string v2;
	    tie (v1, v2) = x->hash ();

	    cout <<
	      "\n enter active node (elemant number (id) ) you are inside it to  search using  routing table   \n";
	    cin >> i;
	    x->search_value (v1, v2, i);
	  }
	  break;


	case 8:
	  {
	    x->print_key ();
	  }
	  break;



	case 9:
	  {
	    exit (1);
	  }
	  break;


	}
    }
    
    cout <<"amr jaara and yazan solila and osama bzour";
  return 0;
}
